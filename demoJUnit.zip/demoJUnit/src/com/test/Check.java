package com.test;
import org.junit.Test;
import org.junit.Assert;
import org.junit.*;
import com.java.*;


//@Test,@After,@Before,@BeforeClass,@afterClass

public class Check {
	static Calculate c=null;
	//static Check cc=new Check();
	
	
	@BeforeClass
	public  static void sayHello()
	{
	System.out.println("before test class");	
	//cc.c=new Calculate();
	c=new Calculate();
	}
	

@Before
public void beforeTest()
{
System.out.println("before testing");	
}


@Test
public void show()
{
	//Assert.assertEquals(22, cc.c.add(12, 10));
	Assert.assertEquals(22, c.add(12, 10));
}
@After
public void afterTest()
{
System.out.println("after testing");	
}	
	
@AfterClass
public  static void sayBye()
{
System.out.println("after test class");	

}

}
