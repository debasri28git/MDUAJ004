package com.test;






import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses({
	
   Check.class,
   Check2.class
})

public class TestSuit {

}
