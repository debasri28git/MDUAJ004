package com.test;

import org.junit.Test;

import com.java.ShowException;

public class TestException {
	ShowException se=new ShowException();
	
	@Test(expected = ArithmeticException.class)
	public void testArithmeticException() {
		int a=9;
		int b=0;
		int c=a/b;
	}

	@Test(expected = NumberFormatException.class)
	public void testNumberFormatException() {
		
		int c=Integer.parseInt("5a");
	}
	
	@Test(expected = Exception.class)
	public void testStringException() {
		
		se.StringRotate();
	}
	
}
