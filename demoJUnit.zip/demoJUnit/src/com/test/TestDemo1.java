package com.test;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.java.Demo1;

public class TestDemo1 {
	Demo1 d=new Demo1();
	
	
	@Test
	public void testAddition() {
		//fail("Not yet implemented");
		
		//int actual=d.addition(5, 8);
		//int expected=13;
		Assert.assertEquals(13, d.addition(5,8));
		//Assert.assertTrue(true);
	}

	@Test
	public void testMerge() {
		//fail("Not yet implemented");
		
		String actual=d.merge("hello", "JUnit");
		String expected="hello JUnit";
		Assert.assertEquals(expected, actual);
		//Assert.assertTrue(true);
	}

	@Test
	public void checkLengthTest_true() {
		assertTrue("pass",new Demo1().checkLength("hello junit"));
		
	}
	@Ignore
	@Test
	public void checkLengthTest_false() {
		assertFalse("not pass",new Demo1().checkLength("helloJunit"));
		
	}
}
