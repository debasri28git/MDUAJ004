package com.test;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.java.Calculate;

public class Check2 {
	static Calculate c=null;
	
	@BeforeClass
	public  static void sayHello()
	{
	System.out.println("before test class");	
	//cc.c=new Calculate();
	c=new Calculate();
	}
	
	
	
	@Test
	public void show()
	{
		//Assert.assertEquals(22, cc.c.add(12, 10));
		Assert.assertEquals(2, c.sub(12, 10));
	}
}
