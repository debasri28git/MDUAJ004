package com.java;
public class ShowException {

	public void StringRotate()throws StringIndexOutOfBoundsException
	{
		String str="hello junit";
		str.charAt(25);
	}
}
