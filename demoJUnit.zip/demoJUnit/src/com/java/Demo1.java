package com.java;
public class Demo1 {

	public int addition(int x,int y)
	{
		return (x+y);
	}
	
	public String merge(String a,String b)
	{
		
		return (a+" "+b);
	}
	
	public boolean checkLength(String a)
	{
		if(a.length()>=10)
		return true;
		else
			return false;
	}
	
}
