package com.java;

public class UseParameter {

	public int add(int a,int b)
	{
		
		return a+b;
	}
	
}
